#!/bin/bash

SHELL_PATH=`pwd -P`
echo $SHELL_PATH
FILE_PATH="$SHELL_PATH/new.sql"
echo $FILE_PATH

echo "--------------------------------------------------------"
echo "                     VTM 패치 실행                      "
echo "--------------------------------------------------------"

cp -f $SHELL_PATH/controllers/*.php /app/vtm/application/controllers/

echo "--------------------------------------------------------"
echo "                    complete hotfix                     "
echo "--------------------------------------------------------"

