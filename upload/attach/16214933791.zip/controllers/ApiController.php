<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ApiController extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model("ApiModel");
		$this->load->helper("download");
		$this->load->helper("file");

        // $this->customclass->sessionCheck();

	}
	
	public function MakeVulnerLogForArcher(){
		$DOC = $this->ApiModel->getVulnerBaseInfo();
		$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/VulnerInfo.csv', 'w');
		fputs( $fp, "\xEF\xBB\xBF");
	    $header = array("No", "DOC_CHECK_REASON", "RA_ASSET_GB", "CATEGORY", "GROUP_CD", "ASSET_NAME", "USER_NAME", "NET_IPADDR", "NET_URL", "ASSETROLE_NM", "SSEC_CODE", "SSEC_RISK", "SSEC_STATE", "SSEC_S_TIME", "SSEC_V_NAME", "APPS_ID", "APPS_RISK", "APPS_V_NAME", "APPS_ID_HOST", "APPS_ID_PORT", "APPS_CWE", "APPS_CVSS", "FTN_V_NAME", "FTN_F_PATH", "FTN_F_NAME", "FTN_F_LINE", "FTN_RISK", "NEX_V_NAME", "NEX_CVE", "NEX_RISK", "MOBILE_V_NAME", "MOBILE_V_EXP", "MOBILE_REC", "MOBILE_RISK", "PROC_GB", "COMP_DATE", "M_OWN");
		fputcsv($fp, $header,',',chr(0));
		$total = count($DOC);
	    foreach ($DOC as $fields) {
			fputcsv($fp, get_object_vars($fields),',',chr(0));
	    }
	    fclose($fp);
	   
	}
	
	public function MakeAssetLogForArcher(){
	    $result = $this->ApiModel->getAssetInfo();
		$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/AssetInfo.csv', 'w');
		fputs( $fp, $bom = chr(0xEF) . chr(0xBB) . chr(0xBF) );
	    $header = array("ASSET_SEQ","CATEGORY","DIVISION","SECTION","GROUP_CD","ASSET_ID","ASSET_NAME","ASSETROLE_NM","ASSETROLE_SEQ","DESCRIPTION","OWNER","DEPT_NM","MANAGER","STATUS","ENABLE","CONFIDENTIALITY","INTEGRITY ","AVAILABILITY","CREATE_DAY","MODIFY_DAY","EXPIRE_DAY","DEV_MANUFACTURER","DEV_MODEL","DEV_SERIAL_NO","DEV_ENV","DEV_SIZE","SYS_CPUMODEL","SYS_PROCNUM","SYS_MEMSIZE","SYS_TOTALSTROAGESIZE","SYS_HDSPEC","LOC_BUILDING","LOC_FLOOR","LOC_ROOM","LOC_RACK","LOC_RACKIN","NET_IPVER","NET_IPADDR","NET_IPCIDR","NET_IFACE","NET_IFACEROLE","NET_MACADDR","SYS_OSTYPE","SYS_OSVER","SYS_HOSTNM","DB_BACKUP_YN","DB_BACKUP_PERIOD","DB_CLUSTER_YN","DB_BACKUPINFO","LCS_MANUFACTURE","LCS_NAME","LCS_VER","LCS_PLATFORM","LCS_TYPE","LCS_KEY","LCS_AUTH_TP","LCS_TOTAL_NUM","LCS_ACTIVE_NUM","LCS_UNUSED_NUM","LCS_USEDBY");
	    fputcsv($fp, $header,',',chr(0));
	    foreach ($result as $fields) {
	        fputcsv($fp, get_object_vars($fields),',',chr(0));
	    }
	    fclose($fp);
	}
		
	public function MakeGroupInfoForArcher(){
		date_default_timezone_set('Asia/Seoul');
	   $result = $this->ApiModel->getGroupInfo();
	//    print_r($result);
	//    exit;
	   $fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/GroupInfo.csv', 'w');
	   fputs( $fp, $bom =( chr(0xEF) . chr(0xBB) . chr(0xBF) ));
	   $header = array("GROUP_SEQ", "GROUP_NAME", "DESCRIPTION", "GROUP_REG_DATE", "TOTAL_DEVICE", "TOTAL_NUMBER", "MEMBER_LIST", "DEVICES");
	   fputcsv($fp, $header,',',chr(0));

	   foreach ($result as $fields) {
		   	$member = "";
			foreach($this->ApiModel->getMember($fields->UG_SEQ) as $val){
				$member .= $val->USER_ID . ", " . $val->USER_NAME . ";";
			}
			$device = "";
			foreach($this->ApiModel->getDevices($fields->UG_SEQ) as $val){
				$device .= $val->ASSET_SEQ . ", " . $val->ASSET_NAME;
			}
			$data = array(
				$fields->UG_SEQ,
				$fields->UG_NAME,
				$fields->UG_DESC,
				$fields->UG_REG_DATE,
				$this->ApiModel->getTotalDevice($fields->UG_SEQ),
				$this->ApiModel->getTotalMember($fields->UG_SEQ),
				$member,
				$device
			);

	       fputcsv($fp, $data);
	   }
	   fclose($fp);
	}
	
	public function DownloadGroupInfoCsv(){
		$path = $_SERVER['DOCUMENT_ROOT'].'/upload/GroupInfo.csv';
		$hash = hash_file('sha1', $path);
		$file = file_get_contents($path);
		force_download($hash . ".csv", $file);
	}

	public function DownloadGroupInfoJson(){
		$ALLOW_IP = $_SERVER['REMOTE_ADDR'];
		print_r($ALLOW_IP);
		if($ALLOW_IP == "127.0.0.1"){
			$str = read_file($_SERVER['DOCUMENT_ROOT'].'/upload/GroupInfo.csv');
			print_r($str);
		} else {
			print("접근권한이 없습니다.");
		}
	}

	public function MakeUserInfoForArcher(){
		date_default_timezone_set('Asia/Seoul');
	   $result =  $this->ApiModel->getCMDBInfo();
	   $fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/UserInfo.csv', 'w');
	   fputs( $fp, $bom =( chr(0xEF) . chr(0xBB) . chr(0xBF) ));
	   $header = array("Field/Section","Contacts ID","Name_Full","Employee ID","Employment Status","Title","Company","Department","Business Unit", "Business Name", "Bus. Address","Bus. City","Email (Business)","Mobile number","Create time","Update time");
	   fputcsv($fp, $header,',',chr(0));
	   foreach ($result as $fields) {
			$data = array(
				"",
				"",
				$fields->user_nm,
				$fields->user_id,
				"active",
				$fields->pos_nm,
				"BSBK",
				"",
				$fields->dept_cd,
				$fields->dept_nm,
				"",
				"",
				"",
				$fields->mobile_tel,
				date('Y-m-d H:i:s'),
				date('Y-m-d H:i:s')
			);

	       fputcsv($fp, $data);
	   }
	   fclose($fp);
	}

	public function MakeDivisionForArcher(){
		$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/Division.csv', 'w');
		fputs( $fp, $bom =( chr(0xEF) . chr(0xBB) . chr(0xBF) ) );
		$divRes = $this->ApiModel->getDivisionInfo();
		$header = array("Field/Section","Division ID","Division","Company","Division Manager","Create time","Update time","Description","Key Contacts","Total Applications","Total Devices","Business Units","Inherent Risk","Residual Risk","History Log","dept_order","dept_pcd","dept_pnm");
		fputcsv($fp, $header,',',chr(0));
		foreach($divRes as $row){
			preg_match('/^B/i', $row->dept_cd, $aaa);
			if($aaa){
				$pcode  = "BSBK";
				$pName  = "부산은행";
			}else{
				$pcode  = $row->dept_pcd;
				$PName = $this->ApiModel->getPName($pcode);
				$pName  = $PName->dept_nm;
			}

			$data = array(
				"",
				$row->dept_cd,
				$row->dept_nm,
				"부산은행",
				"",
				$row->_time,
				$row->_time,
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				$row->dept_odr,
				$pcode,
				$pName 
			);
			fputcsv($fp, $data);
		}
		fclose($fp);
	}
	public function MakeBizUnitForArcher(){
		$fp = fopen($_SERVER['DOCUMENT_ROOT'].'/upload/BusinessUnit.csv', 'w');
		fputs( $fp, $bom = chr(0xEF) . chr(0xBB) . chr(0xBF) );
		$bizUnitRes = $this->ApiModel->getBizUnitInfo();
		$header = array("Field/Section","Business Unit ID","Business Unit","Division","Business Unit Manager","Risk Manager","Create time","Update time","Description","Key Contacts","Total Applications","Total Devices","Applications","Devices","Inherent Risk","Residual Risk","Risk Register","History Log","dept_order","dept_pcd","dept_pnm");
		fputcsv($fp, $header,',',chr(0));
		
		foreach($bizUnitRes as $row){
			
			$pcode  = $row->dept_pcd;
			$PName = $this->ApiModel->getPName($pcode);
			$pName  = $PName->dept_nm;
			$data = array(
				"",
				$row->dept_cd,
				$row->dept_nm,
				$pName,
				$row->deptmgr_id,
				"",
				$row->_time,
				$row->_time,
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				$row->dept_odr,
				$row->dept_pcd,
				$pName
			);
			fputcsv($fp, $data);
		}
		fclose($fp);
	}
	
	public function ConvertOrgPartInfo(){
	   	$result =  $this->ApiModel->getCMDBPartInfo();
		
		// 위드컬렉터 데이터 업데이트 
		foreach($result as $row){
			$data = array(
				"DEPART_CODE" => $row->dept_cd,
				"DEPART_PARENT_CODE" => $row->dept_pcd,
				"DEPART_NAME" => $row->dept_nm,
				"DEPTH" => $row->dept_odr
				
			);
			
			
			$DeptCode = $row->dept_cd;
			$chkData = $this->ApiModel->chkDeptData($DeptCode);
			
			if(!$chkData){
				$data = array(
					"DEPART_CODE" => $row->dept_cd,
					"DEPART_PARENT_CODE" => $row->dept_pcd,
					"REF" => $row->dept_odr,
					"DEPART_NAME" => $row->dept_nm,
					"DEPTH" => $row->dept_odr
				);
				$INST = $this->ApiModel->instDept($data);
			}else{
				$data = array(
					"DEPART_PARENT_CODE" => $row->dept_pcd,
					"REF" => $row->dept_odr,
					"DEPART_NAME" => $row->dept_nm,
					"DEPTH" => $row->dept_odr
				);

				$UPT = $this->ApiModel->uptDept($data, $DeptCode);

			}
		}

	}

	// CMDB 직급코드 업데이트 
	public function setLevel(){
		$result = $this->ApiModel->getBnkLevel();

		foreach($result as $row){
			if($row->pos_cd){
				$chkLevel = $this->ApiModel->chkLevelExist($row->pos_cd);
				if($chkLevel){
					$data = array(
						"USLEV_NAME"=>$row->pos_nm,
						"USLEV_ORDER"=>$row->pos_odr,
						"USLEV_KEY"=>$row->pos_cd,
						"USLEV_PART"=>"position"
					);
					$uptLevel = $this->ApiModel->uptLevelInfo($data, $row->pos_cd);

				}else{
					$data = array(
						"USLEV_CODE"=>$row->pos_cd,
						"USLEV_NAME"=>$row->pos_nm,
						"USLEV_ORDER"=>$row->pos_odr,
						"USLEV_KEY"=>$row->pos_cd,
						"USLEV_PART"=>"position"
					);
					$this->ApiModel->addLevelInfo($data);
				}
			}

		}

	}

	// CMDB 유저정보 업데이트 
	public function setUserInfo(){
		$result =  $this->ApiModel->getCMDBInfo();
		$add_user_arr = [];

		foreach($result as $row){
			array_push($add_user_arr, $row->user_id);
			if($row->user_id){
				$chkLevel = $this->ApiModel->chkUserExist($row->user_id);
				if($chkLevel){
					$data = array(
						"USER_NAME" => $row->user_nm, 
						"USER_TEAM" => $row->dept_cd, 
						"USER_LEVEL" => $row->pos_cd, 
						"USER_EMAIL" => $row->mail_addr, 
						"USER_TEL" => $row->mobile_tel
					);
					$uptLevel = $this->ApiModel->uptUserInfo($data, $row->user_id);

				}else{
					$data = array(
						"USER_ID" => $row->user_id, 
						"USER_NAME" => $row->user_nm, 
						"USER_TEAM" => $row->dept_cd, 
						"USER_LEVEL" => $row->pos_cd, 
						"USER_EMAIL" => $row->mail_addr, 
						"USER_TEL" => $row->mobile_tel
					);
					
					$this->ApiModel->addUserInfo($data);
				}
			}
		}

		print_r($add_user_arr);

	}


}
