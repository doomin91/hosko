<header>
    <div class="header_con">
        <h1><a href="/">Hosko</a></h1>
        <nav class="gnb">
            <ul class="gnb_depth_1">
                <li>HOME</li>
                <li>HOSKO</li>
                <li>공지&뉴스</li>
                <li>포지션 공고</li>
                <li>해외연수</li>
                <li>해외취업가이드</li>
                <li>상담ㆍ신청</li>
                <li>마이페이지</li>
            </ul>
        </nav>
        <!--
        <div class="header_util">
            <ul>
                <li>Login</li>
                <li>더보기</li>
            </ul>
        </div>
-->
    </div>
</header>